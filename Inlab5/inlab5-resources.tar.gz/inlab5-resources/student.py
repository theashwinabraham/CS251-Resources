
class Student:
    def __init__(self, name, age, cgpa, gender, home_town):
        self.name = name
        self.age = age
        self.cgpa = cgpa
        self.gender = gender
        self.home_town = home_town

    def get_name(self):
        r"""
            Returns the name attribute
        """
        pass
    
    def get_age(self):
        r"""
            Returns the age attribute
        """
        pass

    def get_cgpa(self):
        r"""
            Returns the cgpa attribute
        """
        pass
    
    def get_gender(self):
        r"""
            Returns the name attribute
        """
        pass

    def get_home_town(self):
        r"""
            Returns the home_town attribute
        """
        pass