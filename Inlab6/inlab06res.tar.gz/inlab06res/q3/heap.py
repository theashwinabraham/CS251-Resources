class Heap:
    
    def __init__(self, cap):
        self.H = []
        self.n = 0
        self.M = cap
    
    def parent(self, i):
        return (i - 1) // 2
    
    def left(self, i):
        return (2 * i) + 1
    
    def right(self, i):
        return 2 * (i + 1)
    
    def insert(self, val):
        if self.n != self.M:
            self.H[self.n] = val
            i = self.n
            self.n += 1
            while i != 0 and self.H[self.parent(i)] > self.H[i]:
                self.H[i], self.H[self.parent(i)] = self.H[self.parent(i)], self.H[i]
                i = self.parent(i)
    
    def min(self):
        if (self.n != 0):
            return self.H[0]
        return -1
    
    def Heapify(self, root):
        l = self.left(root)
        r = self.right(root)
        s = root
        if (l < self.n and self.H[l] < self.H[root]):
            s = l
        if (r < self.n and self.H[r] < self.H[s]):
            s = r
        if s != root:
            self.H[root], self.H[s] = self.H[s], self.H[root]
            self.Heapify(s)
    
    def deleteMin(self):
        if n > 0:
            if n == 1:
                self.H = []
                n = 0
            else:
                n -= 1
                self.H[0] = self.H[n]
                self.Heapify(0)