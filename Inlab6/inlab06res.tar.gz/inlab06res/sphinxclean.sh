#!/bin/bash

rm -rf build
rm -rf __pycache__