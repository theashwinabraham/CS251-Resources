import random

def getMagicNumber(x):
    num = random.randint(x,x+20)
    print(num)
    return num
