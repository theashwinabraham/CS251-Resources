#include "hashing.hpp"

int hash_string(string s) {
    // implement hashing function here
}