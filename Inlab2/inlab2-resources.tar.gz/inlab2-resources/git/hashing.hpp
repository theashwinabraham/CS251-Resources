#ifndef _HASHING
#define _HASHING

#include <iostream>
#include <string>

using namespace std;


int hash_string(string s);

#endif