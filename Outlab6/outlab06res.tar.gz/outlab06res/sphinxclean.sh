#!/bin/bash

rm -rf build
rm -rf source
rm -rf __pycache__