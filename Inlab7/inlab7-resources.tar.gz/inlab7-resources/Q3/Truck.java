package Q3 ;

/*
 * TODO: Create class Truck along with proper methods and inheritance as required
 */