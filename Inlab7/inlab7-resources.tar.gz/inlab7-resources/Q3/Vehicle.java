package Q3;

/*
 * TODO: Create class Vehicle along with given attributes and methods 
 */