package Q3;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;

public class PollutionCheck {
    public static void main(String [] args) throws Exception {
        /*
         * Implement this function to produce the desired outputs
         */
    }
}