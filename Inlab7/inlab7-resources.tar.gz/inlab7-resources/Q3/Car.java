package Q3 ;

/*
 * TODO: Create class Car along with proper methods and inheritance as required
 */