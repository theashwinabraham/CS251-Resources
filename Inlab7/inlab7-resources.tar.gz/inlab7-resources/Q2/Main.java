package Q2;

public class Main {

    /*
     * NOTE: Create helper functions here if required
     */
    
    public static void main(String args[]) {
        /*
         * TODO: Complete this method
         * NOTE: Take input from STDIN and print the output to STDOUT
         */
        
    }
}
