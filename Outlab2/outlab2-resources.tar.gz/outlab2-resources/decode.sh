#!/bin/bash

pattern=''
word=''

#add your logic here

echo "Last Word found: $word"
echo "Last Pattern found: $pattern"
