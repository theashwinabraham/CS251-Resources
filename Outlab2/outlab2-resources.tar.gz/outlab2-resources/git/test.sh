g++ hashing.cpp main.cpp
echo $1 | ./a.out